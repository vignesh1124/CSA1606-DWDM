"""
Experiment 30: Mall customer segmentation using K-Means clustering
(Customer ID, Age, Annual Income, Spending Score) to identify 5 customer
segments: Usual, Priority, Senior Citizen Target, Young Target, etc.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

rng = np.random.default_rng(5)
n = 200
gender = rng.choice(["Male", "Female"], n)
age = rng.integers(18, 70, n)
income = rng.integers(15, 140, n)
# Spending score correlated in clusters with income for interesting segments
spending = np.clip(
    50 + 40 * np.sin(income / 20) + rng.normal(0, 15, n), 1, 100
).astype(int)

df = pd.DataFrame({
    "CustomerID": range(1, n + 1),
    "Gender": gender,
    "Age": age,
    "AnnualIncome_k$": income,
    "SpendingScore": spending,
})
print(df.head(10).to_string(index=False))
df.to_csv("mall_customers.csv", index=False)

X = df[["AnnualIncome_k$", "SpendingScore"]].values
X_scaled = StandardScaler().fit_transform(X)

k = 5
km = KMeans(n_clusters=k, random_state=42, n_init=10)
df["Cluster"] = km.fit_predict(X_scaled)

print(f"\nK-Means with k={k} clusters")
print(df.groupby("Cluster")[["Age", "AnnualIncome_k$", "SpendingScore"]].mean().round(2))
print("\nCluster sizes:")
print(df["Cluster"].value_counts().sort_index())

plt.figure(figsize=(7, 6))
colors = ["red", "blue", "green", "purple", "orange"]
for c in range(k):
    subset = df[df.Cluster == c]
    plt.scatter(subset["AnnualIncome_k$"], subset["SpendingScore"],
                color=colors[c], label=f"Cluster {c}", alpha=0.7)
plt.xlabel("Annual Income (k$)")
plt.ylabel("Spending Score (1-100)")
plt.title("Mall Customer Segmentation (K-Means, k=5)")
plt.legend()
plt.savefig("exp30_mall_clusters.png", dpi=110)
plt.close()

print("\nSegment interpretation (based on income/spending pattern):")
print(" - Low income, low spending  -> 'Usual Customers'")
print(" - Low income, high spending -> 'Young Target Customers'")
print(" - High income, low spending -> 'Priority Customers' (careful spenders)")
print(" - High income, high spending -> 'Senior Citizen Target Customers'")
print(" - Mid income, mid spending  -> 'Average Customers'")
print("\nSaved: mall_customers.csv, exp30_mall_clusters.png")
