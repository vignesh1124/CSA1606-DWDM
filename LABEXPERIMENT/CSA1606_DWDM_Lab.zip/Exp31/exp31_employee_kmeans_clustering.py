"""
Experiment 31: K-Means clustering on employee dataset (CSV format).
Vary cluster size (k) and visualize the clustering.

EmployeeID  Gender  Age  Salary   Credit
111         Male    28   150000   39
222         Male    25   150000   27
333         Female  26   160000   42
444         Female  25   160000   40
555         Female  30   170000   64
666         Male    29   200000   72
"""
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler

data = {
    "EmployeeID": [111, 222, 333, 444, 555, 666],
    "Gender": ["Male", "Male", "Female", "Female", "Female", "Male"],
    "Age": [28, 25, 26, 25, 30, 29],
    "Salary": [150000, 150000, 160000, 160000, 170000, 200000],
    "Credit": [39, 27, 42, 40, 64, 72],
}
df = pd.DataFrame(data)
df.to_csv("employee_data.csv", index=False)
print(df)

X = df[["Age", "Salary", "Credit"]].values
X_scaled = StandardScaler().fit_transform(X)

fig, axes = plt.subplots(1, 3, figsize=(15, 5))
for i, k in enumerate([2, 3, 4]):
    km = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = km.fit_predict(X_scaled)
    df[f"Cluster_k{k}"] = labels
    print(f"\nK-Means with k={k}:")
    print(df[["EmployeeID", f"Cluster_k{k}"]])
    ax = axes[i]
    scatter = ax.scatter(df["Salary"], df["Credit"], c=labels, cmap="viridis", s=100)
    ax.set_xlabel("Salary")
    ax.set_ylabel("Credit")
    ax.set_title(f"K-Means (k={k})")

plt.tight_layout()
plt.savefig("exp31_employee_clusters_varying_k.png", dpi=110)
plt.close()

print("\nSaved: employee_data.csv, exp31_employee_clusters_varying_k.png")
