"""
Experiment 12: Covariance and Correlation
Children's preference for photographs A, B, C across three age groups.

              A    B    C
5-6 years:   18   22   20
7-8 years:    2   28   40
9-10 years:  20   10   40
"""
import numpy as np

A = np.array([18, 2, 20])
B = np.array([22, 28, 10])
C = np.array([20, 40, 40])

print("Photograph preference counts:")
print(f"  A = {A.tolist()}")
print(f"  B = {B.tolist()}")
print(f"  C = {C.tolist()}")

# cov() between B and C
cov_BC = np.cov(B, C, ddof=1)[0, 1]
print(f"\n(1) Sample covariance between B and C = {cov_BC:.4f}")

# covariance matrix
mat = np.vstack([A, B, C])
cov_matrix = np.cov(mat, ddof=1)
print("\n(2) Sample covariance matrix (rows/cols = A, B, C):")
print(cov_matrix)

# correlation between B and C
corr_BC = np.corrcoef(B, C)[0, 1]
print(f"\n(3) Sample correlation between B and C = {corr_BC:.4f}")

# correlation matrix
corr_matrix = np.corrcoef(mat)
print("\n(4) Sample correlation matrix (rows/cols = A, B, C):")
print(corr_matrix)

print("""
Interpretation:
The counts here are frequencies of a categorical response (photo chosen)
observed for 3 age groups, not paired numeric measurements on the same
individuals -- this is really contingency-table data. Treating the three
age-group totals as 3 'observations' per photograph column is a common
classroom simplification, but it does not properly test whether age and
photo preference are related. A chi-square test of independence on the
3x3 contingency table would be the statistically appropriate method
instead of covariance/correlation between columns.
""")
