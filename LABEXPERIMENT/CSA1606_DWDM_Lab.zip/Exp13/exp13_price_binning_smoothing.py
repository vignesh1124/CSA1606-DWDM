"""
Experiment 13: All Electronics price data
1,1,5,5,5,5,5,8,8,10,10,10,10,12,14,14,14,15,15,15,15,15,15,18,18,18,18,18,18,
18,18,20,20,20,20,20,20,20,21,21,21,21,25,25,25,25,25,28,28,30,30,30
  (i)   Partition using equal-frequency partitioning, bin size = 3
  (ii)  Data smoothing using bin means and bin boundaries
  (iii) Plot histogram
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

prices = [1,1,5,5,5,5,5,8,8,10,10,10,10,12,14,14,14,15,15,15,15,15,15,18,18,18,
          18,18,18,18,18,20,20,20,20,20,20,20,21,21,21,21,25,25,25,25,25,28,28,
          30,30,30]

print(f"n = {len(prices)}")
print("Data:", prices)

bin_size = 3
bins = [prices[i:i + bin_size] for i in range(0, len(prices), bin_size)]

print(f"\n(i) Equal-frequency partitioning with bin size = {bin_size}:")
for i, b in enumerate(bins, 1):
    print(f"  Bin {i}: {b}")

print("\n(ii-a) Smoothing by bin means:")
for i, b in enumerate(bins, 1):
    m = round(np.mean(b), 2)
    print(f"  Bin {i}: {[m]*len(b)}")

print("\n(ii-b) Smoothing by bin boundaries:")
for i, b in enumerate(bins, 1):
    low, high = min(b), max(b)
    smoothed = [low if abs(v - low) <= abs(v - high) else high for v in b]
    print(f"  Bin {i}: {smoothed} (min={low}, max={high})")

plt.figure(figsize=(8, 5))
plt.hist(prices, bins=10, color="cornflowerblue", edgecolor="black")
plt.xlabel("Price ($)")
plt.ylabel("Frequency")
plt.title("Histogram of All Electronics Prices")
plt.savefig("exp13_histogram.png", dpi=110)
plt.close()
print("\nSaved plot: exp13_histogram.png")
