"""
Experiment 24: Bayes Classification and Decision Tree
(buys_computer dataset - classic Han/Kamber example)
Train on the 14 records, then predict for a new/test tuple.
"""
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.naive_bayes import CategoricalNB
from sklearn.tree import DecisionTreeClassifier, export_text

data = {
    "age":     ["<=30","<=30","31...40",">40",">40",">40","31...40","<=30","<=30",">40","<=30","31...40","31...40",">40"],
    "income":  ["high","high","high","medium","low","low","low","medium","low","medium","medium","medium","high","medium"],
    "student": ["no","no","no","no","yes","yes","yes","no","yes","yes","yes","no","yes","no"],
    "credit_rating": ["fair","excellent","fair","fair","fair","excellent","excellent","fair","fair","fair","excellent","excellent","fair","excellent"],
    "buys_computer": ["no","no","yes","yes","yes","no","yes","no","yes","yes","yes","yes","yes","no"],
}
df = pd.DataFrame(data)
print(df)

encoders = {col: LabelEncoder().fit(df[col]) for col in df.columns}
enc_df = pd.DataFrame({col: encoders[col].transform(df[col]) for col in df.columns})

X = enc_df.drop(columns=["buys_computer"])
y = enc_df["buys_computer"]

# --- Naive Bayes ---
nb = CategoricalNB()
nb.fit(X, y)

# Test tuple: age<=30, income=medium, student=yes, credit_rating=fair
test_raw = {"age": "<=30", "income": "medium", "student": "yes", "credit_rating": "fair"}
test_enc = [[encoders[c].transform([test_raw[c]])[0] for c in X.columns]]
pred_nb = nb.predict(test_enc)
pred_proba = nb.predict_proba(test_enc)
pred_label = encoders["buys_computer"].inverse_transform(pred_nb)[0]

print("\n--- Naive Bayes Classification ---")
print(f"Test tuple: {test_raw}")
print(f"Predicted class probabilities (order={list(encoders['buys_computer'].classes_)}): "
      f"{pred_proba.round(4).tolist()}")
print(f"Predicted class (buys_computer): {pred_label}")

# --- Decision Tree ---
dt = DecisionTreeClassifier(criterion="entropy", random_state=0)
dt.fit(X, y)
pred_dt = dt.predict(test_enc)
pred_dt_label = encoders["buys_computer"].inverse_transform(pred_dt)[0]

print("\n--- Decision Tree Classification ---")
tree_rules = export_text(dt, feature_names=list(X.columns))
print(tree_rules)
print(f"Predicted class for test tuple (buys_computer): {pred_dt_label}")

train_acc_nb = nb.score(X, y)
train_acc_dt = dt.score(X, y)
print(f"\nTraining accuracy - Naive Bayes: {train_acc_nb:.3f}")
print(f"Training accuracy - Decision Tree: {train_acc_dt:.3f}")
