"""
Experiment 42:
T100 {M,O,N,K,E,Y}  T200 {D,O,N,K,E,Y}  T300 {M,A,K,E}
T400 {M,U,C,K,Y}    T500 {C,O,O,K,I,E}
  a) Find all frequent itemsets using Apriori and FP-Growth; compare
     efficiency of the two mining processes.
  b) List all strong association rules (support s, confidence c) matching
     the metarule: buys(X,item1) ^ buys(X,item2) => buys(X,item3)
"""
import time
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, fpgrowth, association_rules

transactions = [
    sorted(set("MONKEY")),
    sorted(set("DONKEY")),
    sorted(set("MAKE")),
    sorted(set("MUCKY")),
    sorted(set(["C", "O", "O", "K", "I", "E"])),
]
for i, t in enumerate(transactions, 1):
    print(f"T{100*i}: {t}")

te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

n = len(transactions)
min_support = 2 / n   # 40% (2 out of 5)
min_conf = 0.60

print(f"\nmin_support = {min_support:.2f} (>=2 of {n} transactions), min_confidence = {min_conf}")

t0 = time.perf_counter()
freq_a = apriori(df, min_support=min_support, use_colnames=True)
t_apriori = time.perf_counter() - t0

t0 = time.perf_counter()
freq_f = fpgrowth(df, min_support=min_support, use_colnames=True)
t_fp = time.perf_counter() - t0

print(f"\n(a) Apriori found {len(freq_a)} frequent itemsets in {t_apriori*1000:.3f} ms")
print(freq_a.sort_values("support", ascending=False).to_string(index=False))

print(f"\nFP-Growth found {len(freq_f)} frequent itemsets in {t_fp*1000:.3f} ms")
print(freq_f.sort_values("support", ascending=False).to_string(index=False))

print(f"\nEfficiency comparison: FP-Growth scans the database only twice and mines")
print("via a compact tree structure (no candidate generation), so it is generally")
print("faster and more memory-efficient than Apriori on larger datasets, even though")
print("on this tiny 5-transaction example the timing difference is negligible")
print(f"(Apriori: {t_apriori*1000:.3f} ms vs FP-Growth: {t_fp*1000:.3f} ms).")

rules = association_rules(freq_a, metric="confidence", min_threshold=min_conf, num_itemsets=len(freq_a))
# Rules matching metarule: 2-item antecedent -> 1-item consequent
metarule_matches = rules[(rules.antecedents.apply(len) == 2) & (rules.consequents.apply(len) == 1)]

print(f"\n(b) Strong association rules matching metarule "
      f"buys(X,item1)^buys(X,item2) => buys(X,item3)  (2-item antecedent -> 1-item consequent):")
if len(metarule_matches):
    print(metarule_matches[["antecedents", "consequents", "support", "confidence"]]
          .sort_values("confidence", ascending=False).to_string(index=False))
else:
    print("No rules with a 2-item antecedent and 1-item consequent meet the thresholds.")
