"""
Experiment 35: Generate rules using the FP-Growth algorithm.
Transactions:
 1: Bread, Cheese, Egg, Juice
 2: Bread, Cheese, Juice
 3: Bread, Milk, Yogurt
 4: Bread, Juice, Milk
 5: Cheese, Juice, Milk
support = 50%, confidence = 75%
"""
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import fpgrowth, apriori, association_rules

transactions = [
    ["Bread", "Cheese", "Egg", "Juice"],
    ["Bread", "Cheese", "Juice"],
    ["Bread", "Milk", "Yogurt"],
    ["Bread", "Juice", "Milk"],
    ["Cheese", "Juice", "Milk"],
]
for i, t in enumerate(transactions, 1):
    print(f"T{i}: {t}")

te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

n = len(transactions)
min_support = 0.50
min_conf = 0.75
print(f"\nmin_support = {min_support} (count >= {min_support*n:.1f} of {n})")
print(f"min_confidence = {min_conf}")

freq = fpgrowth(df, min_support=min_support, use_colnames=True)
freq["count"] = (freq["support"] * n).round().astype(int)
print("\n--- Frequent Itemsets (FP-Growth) ---")
print(freq.sort_values("support", ascending=False).to_string(index=False))

rules = association_rules(freq, metric="confidence", min_threshold=min_conf, num_itemsets=len(freq))
print(f"\n--- Association Rules (confidence >= {min_conf}) ---")
if len(rules):
    print(rules[["antecedents", "consequents", "support", "confidence", "lift"]]
          .sort_values("confidence", ascending=False).to_string(index=False))
else:
    print("No rules meet the confidence threshold.")

# Cross-check with Apriori
freq_a = apriori(df, min_support=min_support, use_colnames=True)
print(f"\nCross-check: Apriori found {len(freq_a)} frequent itemsets; "
      f"FP-Growth found {len(freq)} (should be identical sets).")
