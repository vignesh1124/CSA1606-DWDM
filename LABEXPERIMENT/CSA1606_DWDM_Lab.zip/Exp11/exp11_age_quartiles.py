"""
Experiment 11: First quartile (Q1) and third quartile (Q3) of the age data
age: 13,15,16,16,19,20,20,21,22,22,25,25,25,25,30,33,33,35,35,35,35,36,40,45,46,52,70
"""
import numpy as np

age = [13,15,16,16,19,20,20,21,22,22,25,25,25,25,30,33,
       33,35,35,35,35,36,40,45,46,52,70]

n = len(age)
q1 = np.percentile(age, 25)
q3 = np.percentile(age, 75)
median = np.median(age)

print(f"n = {n}")
print(f"Sorted data: {age}")
print(f"\nMedian (Q2) = {median}")
print(f"Q1 (25th percentile) = {q1}")
print(f"Q3 (75th percentile) = {q3}")
print(f"IQR = Q3 - Q1 = {q3 - q1}")

# Manual rank-based method (Han/Kamber textbook style) for comparison
def manual_quartile(data, percentile):
    data = sorted(data)
    idx = percentile / 100 * (len(data) - 1)
    lo = int(np.floor(idx))
    hi = int(np.ceil(idx))
    if lo == hi:
        return data[lo]
    frac = idx - lo
    return data[lo] + frac * (data[hi] - data[lo])

print(f"\n(Manual rank-interpolation check) Q1 = {manual_quartile(age,25):.3f}, "
      f"Q3 = {manual_quartile(age,75):.3f}")
