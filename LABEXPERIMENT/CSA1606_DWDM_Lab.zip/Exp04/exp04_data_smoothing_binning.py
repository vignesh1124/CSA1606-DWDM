"""
Experiment 4: Data Smoothing using Binning
Data: 11,13,13,15,15,16,19,20,20,20,21,21,22,23,24,30,40,45,45,45,71,72,73,75
Partitioned into equal-frequency bins of size 3.
  (a) Smoothing by bin means
  (b) Smoothing by bin medians
  (c) Smoothing by bin boundaries
"""
import numpy as np

data = [11,13,13,15,15,16,19,20,20,20,21,21,22,23,24,30,40,45,45,45,71,72,73,75]

bin_size = 3
bins = [data[i:i + bin_size] for i in range(0, len(data), bin_size)]

print("Sorted data:", data)
print(f"\nPartitioned into bins of size {bin_size}:")
for i, b in enumerate(bins, 1):
    print(f"  Bin {i}: {b}")

print("\n(a) Smoothing by bin means:")
for i, b in enumerate(bins, 1):
    m = np.mean(b)
    print(f"  Bin {i}: {[round(m,2)]*len(b)}")

print("\n(b) Smoothing by bin medians:")
for i, b in enumerate(bins, 1):
    med = np.median(b)
    print(f"  Bin {i}: {[med]*len(b)}")

print("\n(c) Smoothing by bin boundaries:")
for i, b in enumerate(bins, 1):
    low, high = min(b), max(b)
    smoothed = [low if abs(v - low) <= abs(v - high) else high for v in b]
    print(f"  Bin {i}: {smoothed}  (min={low}, max={high})")
