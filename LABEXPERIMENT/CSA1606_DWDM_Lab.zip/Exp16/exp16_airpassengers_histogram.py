"""
Experiment 16: Histogram for the AirPassengers dataset
  - x-axis starts at 100
  - bins covering values 200 to 700, bin width = 150
(AirPassengers = classic monthly totals of international airline
passengers, 1949-1960, in thousands; reproduced here as it is not
downloadable in this offline environment.)
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

AirPassengers = [
112,118,132,129,121,135,148,148,136,119,104,118,
115,126,141,135,125,149,170,170,158,133,114,140,
145,150,178,163,172,178,199,199,184,162,146,166,
171,180,193,181,183,218,230,242,209,191,172,194,
196,196,236,235,229,243,264,272,237,211,180,201,
204,188,235,227,234,264,302,293,259,229,203,229,
242,233,267,269,270,315,364,347,312,274,237,278,
284,277,317,313,318,374,413,405,355,306,271,306,
315,301,356,348,355,422,465,467,404,347,305,336,
340,318,362,348,363,435,491,505,404,359,310,337,
360,342,406,396,420,472,548,559,463,407,362,405,
417,391,419,461,472,535,622,606,508,461,390,432
]

print(f"AirPassengers: {len(AirPassengers)} monthly values")
print(f"min = {min(AirPassengers)}, max = {max(AirPassengers)}")

bin_edges = list(range(200, 701, 150))  # 200,350,500,650,(800 not needed but check max)
# Ensure edges cover the requested x-axis start at 100 and go up to >= max in [200,700]
print(f"Requested bin edges (width 150, covering 200-700): {bin_edges}")

plt.figure(figsize=(8, 5))
plt.hist(AirPassengers, bins=bin_edges, color="salmon", edgecolor="black")
plt.xlim(left=100)
plt.xlabel("Number of Passengers (thousands)")
plt.ylabel("Frequency")
plt.title("Histogram of AirPassengers (bins of width 150, from 200 to 700)")
plt.savefig("exp16_airpassengers_histogram.png", dpi=110)
plt.close()

counts, edges = np.histogram(AirPassengers, bins=bin_edges)
print("\nBin counts:")
for i in range(len(counts)):
    print(f"  [{edges[i]}, {edges[i+1]}): {counts[i]}")

print("\nSaved plot: exp16_airpassengers_histogram.png")
