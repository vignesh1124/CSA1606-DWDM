"""
Experiment 25: Analyse 'diabetes.csv' - how the diabetes trend varies for
different age groups, using Linear Regression and Multiple Regression.

NOTE: synthetic Pima-style dataset used (same structure as Experiment 21),
since the original CSV isn't available offline.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import r2_score, mean_squared_error

rng = np.random.default_rng(11)
n = 500
age = rng.integers(21, 81, n)
bmi = rng.normal(30, 6, n).clip(15, 55)
glucose = 90 + 0.6 * age + 0.8 * bmi + rng.normal(0, 15, n)
# Outcome probability increases with age, bmi, glucose
logit = -8 + 0.04 * age + 0.09 * bmi + 0.03 * glucose
prob = 1 / (1 + np.exp(-logit))
outcome = (rng.random(n) < prob).astype(int)

df = pd.DataFrame({"Age": age, "BMI": bmi.round(1), "Glucose": glucose.round(1), "Outcome": outcome})
print(df.describe())

trend = df.groupby(pd.cut(df.Age, bins=[20,30,40,50,60,70,80]), observed=True)["Outcome"].mean()
print("\nDiabetes rate (Outcome=1 proportion) by age group:")
print(trend)

plt.figure(figsize=(7, 5))
trend.plot(kind="bar", color="tomato", edgecolor="black")
plt.ylabel("Diabetes Positive Rate")
plt.title("Diabetes Trend by Age Group")
plt.tight_layout()
plt.savefig("exp25_diabetes_trend_by_age.png", dpi=110)
plt.close()

# --- Simple Linear Regression: Outcome ~ Age ---
X_simple = df[["Age"]]
y = df["Outcome"]
lin_model = LinearRegression().fit(X_simple, y)
print(f"\nSimple Linear Regression (Outcome ~ Age):")
print(f"  Outcome = {lin_model.intercept_:.5f} + {lin_model.coef_[0]:.5f} * Age")
print(f"  R-squared = {lin_model.score(X_simple, y):.4f}")

# --- Multiple Regression: Outcome ~ Age + BMI + Glucose ---
X_multi = df[["Age", "BMI", "Glucose"]]
X_train, X_test, y_train, y_test = train_test_split(X_multi, y, test_size=0.2, random_state=0)
multi_model = LinearRegression().fit(X_train, y_train)
y_pred = multi_model.predict(X_test)

print(f"\nMultiple Regression (Outcome ~ Age + BMI + Glucose):")
print(f"  Coefficients: Age={multi_model.coef_[0]:.5f}, BMI={multi_model.coef_[1]:.5f}, "
      f"Glucose={multi_model.coef_[2]:.5f}")
print(f"  Intercept: {multi_model.intercept_:.5f}")
print(f"  R-squared (train) = {multi_model.score(X_train, y_train):.4f}")
print(f"  R-squared (test)  = {r2_score(y_test, y_pred):.4f}")
print(f"  MSE (test) = {mean_squared_error(y_test, y_pred):.4f}")

print("\nSaved plot: exp25_diabetes_trend_by_age.png")
