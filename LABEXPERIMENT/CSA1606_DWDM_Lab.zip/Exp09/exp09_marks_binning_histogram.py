"""
Experiment 9: Marks scored partitioned into 3 bins
Data: 55,60,71,63,55,65,50,55,58,59,61,63,65,67,71,72,75
  (a) equal-frequency (equi-depth) partitioning
  (b) equal-width partitioning
  Plot histogram of the data points.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

marks = [55,60,71,63,55,65,50,55,58,59,61,63,65,67,71,72,75]
sorted_marks = sorted(marks)
print("Original data:", marks)
print("Sorted data:", sorted_marks)

# (a) Equal-frequency partitioning into 3 bins
n_bins = 3
bin_size = len(sorted_marks) // n_bins
remainder = len(sorted_marks) % n_bins
freq_bins = []
idx = 0
for i in range(n_bins):
    size = bin_size + (1 if i < remainder else 0)
    freq_bins.append(sorted_marks[idx:idx + size])
    idx += size

print("\n(a) Equal-frequency (equi-depth) partitioning into 3 bins:")
for i, b in enumerate(freq_bins, 1):
    print(f"  Bin {i}: {b}")

# (b) Equal-width partitioning into 3 bins
mn, mx = min(sorted_marks), max(sorted_marks)
width = (mx - mn) / n_bins
edges = [mn + i * width for i in range(n_bins + 1)]
width_bins = [[] for _ in range(n_bins)]
for v in sorted_marks:
    b_idx = min(int((v - mn) / width), n_bins - 1)
    width_bins[b_idx].append(v)

print(f"\n(b) Equal-width partitioning into 3 bins (width={width:.2f}):")
for i, b in enumerate(width_bins, 1):
    print(f"  Bin {i} [{edges[i-1]:.1f}-{edges[i]:.1f}]: {b}")

plt.figure(figsize=(7, 5))
plt.hist(marks, bins=n_bins, color="mediumseagreen", edgecolor="black")
plt.xlabel("Marks")
plt.ylabel("Frequency")
plt.title("Histogram of Marks (3 bins)")
plt.savefig("exp09_histogram.png", dpi=110)
plt.close()
print("\nSaved plot: exp09_histogram.png")
