"""
Experiment 23: Market basket transactions (Milk, Beer, Diapers, Bread,
Butter, Cookies, Diapers, ...) - 10 transactions over the item set
{Milk, Bread, Butter, Beer, Diapers, Cookies} (d = 6 distinct items).

(a) Maximum number of association rules that can be extracted from this
    data (including rules with zero support)
(b) Maximum size of frequent itemsets that can be extracted (assuming
    minsup > 0)
"""
from itertools import combinations
from math import comb

transactions = {
    1: {"Milk", "Beer", "Diapers"},
    2: {"Bread", "Butter", "Milk"},
    3: {"Milk", "Diapers", "Cookies"},
    4: {"Bread", "Butter", "Cookies"},
    5: {"Beer", "Cookies", "Diapers"},
    6: {"Milk", "Diapers", "Bread", "Butter"},
    7: {"Bread", "Butter", "Diapers"},
    8: {"Beer", "Diapers"},
    9: {"Milk", "Diapers", "Bread", "Butter"},
    10: {"Beer", "Cookies"},
}

for tid, items in transactions.items():
    print(f"T{tid}: {sorted(items)}")

all_items = sorted(set().union(*transactions.values()))
d = len(all_items)
print(f"\nDistinct items (d) = {d}: {all_items}")

# (a) Maximum number of association rules for d items:
# R = 3^d - 2^(d+1) + 1
max_rules = 3 ** d - 2 ** (d + 1) + 1
print(f"\n(a) Maximum number of association rules (including zero support):")
print(f"    R = 3^d - 2^(d+1) + 1 = 3^{d} - 2^{d+1} + 1 = {max_rules}")

# (b) Maximum size of a frequent itemset = d (assuming minsup > 0 still
# theoretically allows the full itemset if support threshold is very low,
# but practically bounded by the longest transaction)
max_transaction_len = max(len(items) for items in transactions.values())
print(f"\n(b) Maximum possible itemset size (upper bound) = d = {d}")
print(f"    Longest single transaction observed has {max_transaction_len} items,")
print(f"    so in THIS dataset no itemset larger than {max_transaction_len} can ever")
print(f"    be frequent (an itemset can only be frequent if it is a subset of at")
print(f"    least one transaction), i.e. practical max frequent itemset size = "
      f"{max_transaction_len}.")
