"""
Experiment 22: Apriori Algorithm and FP-Growth Algorithm
Transactions (Customer ID, Transaction ID, Items Bought):
 1,0001,{a,d,e}   2,0012,{a,b,d,e}   3,0015,{b,c,e}   4,0029,{c,d}    5,0033,{a,d,e}
 1,0024,{a,b,c,e} 2,0031,{a,c,d,e}   3,0022,{b,d,e}   4,0040,{a,b,c}  5,0038,{a,b,e}

min_support = 3 (absolute count), min_confidence = 50%
"""
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, fpgrowth, association_rules

transactions = [
    ["a", "d", "e"],
    ["a", "b", "c", "e"],
    ["a", "b", "d", "e"],
    ["a", "c", "d", "e"],
    ["b", "c", "e"],
    ["b", "d", "e"],
    ["c", "d"],
    ["a", "b", "c"],
    ["a", "d", "e"],
    ["a", "b", "e"],
]

te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

n_trans = len(transactions)
min_support_count = 3
min_support = min_support_count / n_trans
min_confidence = 0.50

print(f"Number of transactions = {n_trans}")
print(f"min_support (count=3) -> fraction = {min_support:.4f}")
print(f"min_confidence = {min_confidence}")

print("\n--- Apriori Algorithm ---")
freq_apriori = apriori(df, min_support=min_support, use_colnames=True)
freq_apriori["count"] = (freq_apriori["support"] * n_trans).round().astype(int)
print(freq_apriori.sort_values("support", ascending=False).to_string(index=False))

rules_apriori = association_rules(freq_apriori, metric="confidence",
                                   min_threshold=min_confidence, num_itemsets=len(freq_apriori))
print(f"\nAssociation rules (confidence >= {min_confidence}):")
print(rules_apriori[["antecedents", "consequents", "support", "confidence", "lift"]]
      .sort_values("confidence", ascending=False).to_string(index=False))

print("\n--- FP-Growth Algorithm ---")
freq_fp = fpgrowth(df, min_support=min_support, use_colnames=True)
freq_fp["count"] = (freq_fp["support"] * n_trans).round().astype(int)
print(freq_fp.sort_values("support", ascending=False).to_string(index=False))

rules_fp = association_rules(freq_fp, metric="confidence",
                              min_threshold=min_confidence, num_itemsets=len(freq_fp))
print(f"\nAssociation rules (confidence >= {min_confidence}):")
print(rules_fp[["antecedents", "consequents", "support", "confidence", "lift"]]
      .sort_values("confidence", ascending=False).to_string(index=False))

print(f"\nApriori found {len(freq_apriori)} frequent itemsets; "
      f"FP-Growth found {len(freq_fp)} frequent itemsets (should match -- "
      f"both algorithms find the same frequent itemsets, FP-Growth is just faster).")
