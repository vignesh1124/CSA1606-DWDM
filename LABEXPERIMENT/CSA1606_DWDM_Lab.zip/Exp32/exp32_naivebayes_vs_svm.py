"""
Experiment 32: Prediction of categorical data using Naive Bayes vs SVM.
Compare accuracy of the two classifiers and plot the graph.
(WEKA-style task, reproduced with scikit-learn.)
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import GaussianNB
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score

rng = np.random.default_rng(9)
n = 400
age = rng.integers(18, 70, n)
income = rng.normal(50000, 15000, n).clip(15000, 150000)
student = rng.choice(["yes", "no"], n)
score = 0.00002 * income + (age < 30) * 1.5 + (student == "yes") * 1.0 + rng.normal(0, 1, n)
buys = np.where(score > np.median(score), "yes", "no")

df = pd.DataFrame({"age": age, "income": income, "student": student, "buys_computer": buys})
le_student = LabelEncoder().fit(df.student)
le_target = LabelEncoder().fit(df.buys_computer)
X = np.column_stack([df.age, df.income, le_student.transform(df.student)])
y = le_target.transform(df.buys_computer)

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25, random_state=0)
scaler = StandardScaler().fit(X_train)
X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)

nb = GaussianNB().fit(X_train_s, y_train)
svm = SVC(kernel="rbf").fit(X_train_s, y_train)

nb_pred = nb.predict(X_test_s)
svm_pred = svm.predict(X_test_s)

nb_acc, nb_f1 = accuracy_score(y_test, nb_pred), f1_score(y_test, nb_pred)
svm_acc, svm_f1 = accuracy_score(y_test, svm_pred), f1_score(y_test, svm_pred)

print(f"Naive Bayes  -> Accuracy: {nb_acc:.4f}, F1-score: {nb_f1:.4f}")
print(f"SVM          -> Accuracy: {svm_acc:.4f}, F1-score: {svm_f1:.4f}")

plt.figure(figsize=(6, 5))
x_labels = ["Naive Bayes", "SVM"]
accs = [nb_acc, svm_acc]
f1s = [nb_f1, svm_f1]
x = np.arange(2)
w = 0.35
plt.bar(x - w/2, accs, w, label="Accuracy", color="seagreen")
plt.bar(x + w/2, f1s, w, label="F1-score", color="indianred")
plt.xticks(x, x_labels)
plt.ylim(0, 1)
plt.legend()
plt.title("Naive Bayes vs SVM - Accuracy & F1-score")
plt.savefig("exp32_nb_vs_svm.png", dpi=110)
plt.close()
print("\nSaved plot: exp32_nb_vs_svm.png")
