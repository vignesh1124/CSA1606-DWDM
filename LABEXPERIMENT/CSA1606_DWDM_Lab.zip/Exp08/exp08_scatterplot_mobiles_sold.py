"""
Experiment 8: Scatter plot of (x, y) points
x = number of mobile phones sold, y = money earned
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

x = [4, 1, 5, 7, 10, 2, 50, 25, 90, 36]
y = [12, 5, 13, 19, 31, 7, 153, 72, 275, 110]

print("x (phones sold):", x)
print("y (money):", y)

corr = np.corrcoef(x, y)[0, 1]
print(f"\nCorrelation between phones sold and money = {corr:.4f}")
print("The scatter plot shows a strong positive linear relationship: as more")
print("mobile phones are sold, the money earned increases proportionally.")

plt.figure(figsize=(6, 5))
plt.scatter(x, y, color="darkorange", s=60)
plt.xlabel("Number of Mobile Phones Sold")
plt.ylabel("Money")
plt.title("Scatter Plot: Mobile Phones Sold vs Money")
plt.grid(alpha=0.3)
plt.savefig("exp08_scatterplot.png", dpi=110)
plt.close()
print("\nSaved plot: exp08_scatterplot.png")
