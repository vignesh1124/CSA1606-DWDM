"""
Experiment 19: Boxplot for the relationship between 'mpg' and 'cyl'
(number of cylinders) in the mtcars dataset.
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd

mpg = [21.0,21.0,22.8,21.4,18.7,18.1,14.3,24.4,22.8,19.2,17.8,16.4,17.3,15.2,10.4,10.4,14.7,
       32.4,30.4,33.9,21.5,15.5,15.2,13.3,19.2,27.3,26.0,30.4,15.8,19.7,15.0,21.4]
cyl = [6,6,4,6,8,6,8,4,4,6,6,8,8,8,8,8,8,4,4,4,4,8,8,8,8,4,4,4,8,6,8,4]

df = pd.DataFrame({"mpg": mpg, "cyl": cyl})
print(df.groupby("cyl")["mpg"].describe())

groups = [df[df.cyl == c]["mpg"].values for c in sorted(df.cyl.unique())]
labels = [str(c) for c in sorted(df.cyl.unique())]

plt.figure(figsize=(6, 5))
plt.boxplot(groups, tick_labels=labels)
plt.xlabel("Number of Cylinders (cyl)")
plt.ylabel("Miles per Gallon (mpg)")
plt.title("mtcars: mpg by cyl (Boxplot)")
plt.savefig("exp19_mtcars_mpg_cyl_boxplot.png", dpi=110)
plt.close()

print("\nInference: cars with fewer cylinders (4) generally have higher mpg")
print("(better fuel efficiency), while 8-cylinder cars have the lowest mpg.")
print("\nSaved plot: exp19_mtcars_mpg_cyl_boxplot.png")
