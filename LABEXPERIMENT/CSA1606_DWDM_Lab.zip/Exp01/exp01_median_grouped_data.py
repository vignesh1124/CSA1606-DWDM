"""
Experiment 1: Approximate Median for Grouped (Interval, Frequency) Data
-------------------------------------------------------------------------
Age intervals and frequencies:
   1-5    : 200
   5-15   : 450
   15-20  : 300
   20-50  : 1500
   50-80  : 700
   80-110 : 44

Formula:
   Median = L + ((n/2 - CF) / f) * h
   L  = lower boundary of median class
   n  = total frequency
   CF = cumulative frequency before median class
   f  = frequency of median class
   h  = width of median class
"""

intervals = [(1, 5), (5, 15), (15, 20), (20, 50), (50, 80), (80, 110)]
freqs = [200, 450, 300, 1500, 700, 44]

n = sum(freqs)
half_n = n / 2

print("Interval\tFrequency\tCumulative Frequency")
cum = 0
median_class_idx = None
cf_before = 0
for i, ((low, high), f) in enumerate(zip(intervals, freqs)):
    cum += f
    print(f"{low}-{high}\t\t{f}\t\t{cum}")
    if median_class_idx is None and cum >= half_n:
        median_class_idx = i
        cf_before = cum - f

L, H = intervals[median_class_idx]
f_median = freqs[median_class_idx]
h = H - L

median = L + ((half_n - cf_before) / f_median) * h

print(f"\nTotal frequency (n) = {n}")
print(f"n/2 = {half_n}")
print(f"Median class = {L}-{H} (first class where cumulative freq >= n/2)")
print(f"L (lower boundary) = {L}")
print(f"CF (cumulative freq before median class) = {cf_before}")
print(f"f (frequency of median class) = {f_median}")
print(f"h (class width) = {h}")
print(f"\nApproximate Median = {L} + (({half_n} - {cf_before}) / {f_median}) * {h}")
print(f"Approximate Median = {median:.4f}")
