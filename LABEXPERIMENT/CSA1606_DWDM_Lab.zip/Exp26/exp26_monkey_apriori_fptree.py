"""
Experiment 26: (WEKA-style task, implemented here in Python)
Five transactions (classic Han/Kamber 'MONKEY' example):
 T1: M,O,N,K,E,Y
 T2: D,O,N,K,E,Y
 T3: M,A,K,E
 T4: M,U,C,K,Y
 T5: C,O,O,K,I,E
min_sup = 50% (>=2 transactions), min_conf = 80%
  - Find all frequent itemsets using Apriori
  - Draw the FP-Growth tree
"""
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, association_rules
from collections import defaultdict

transactions = [
    list("MONKEY"),
    list("DONKEY"),
    list("MAKE"),
    list("MUCKY"),  # M,U,C,K,Y (dup letters collapse naturally as a set below)
    ["C", "O", "O", "K", "I", "E"],
]
transactions = [sorted(set(t)) for t in transactions]
for i, t in enumerate(transactions, 1):
    print(f"T{i}: {t}")

te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

n = len(transactions)
min_support = 2 / n     # 50%
min_conf = 0.80

print(f"\nmin_sup = 50% (>= {2} of {n} transactions) -> support fraction = {min_support:.2f}")
print(f"min_conf = {min_conf}")

freq = apriori(df, min_support=min_support, use_colnames=True)
freq["count"] = (freq["support"] * n).round().astype(int)
freq = freq.sort_values(["count", "support"], ascending=False)
print("\n--- Frequent Itemsets (Apriori) ---")
print(freq.to_string(index=False))

rules = association_rules(freq, metric="confidence", min_threshold=min_conf, num_itemsets=len(freq))
print(f"\n--- Association Rules (confidence >= {min_conf}) ---")
if len(rules):
    print(rules[["antecedents", "consequents", "support", "confidence", "lift"]].to_string(index=False))
else:
    print("No rules meet the 80% confidence threshold.")

# --- FP-Growth tree construction (text representation) ---
print("\n--- FP-Growth Tree (text representation) ---")
item_counts = defaultdict(int)
for t in transactions:
    for item in t:
        item_counts[item] += 1
frequent_items = {i: c for i, c in item_counts.items() if c >= 2}
order = sorted(frequent_items, key=lambda x: (-frequent_items[x], x))
print(f"Frequent 1-items (count>=2) ordered by frequency: {[(i, frequent_items[i]) for i in order]}")

class Node:
    def __init__(self, name):
        self.name = name
        self.count = 0
        self.children = {}

root = Node("root")
for t in transactions:
    filtered = [i for i in t if i in frequent_items]
    filtered.sort(key=lambda x: order.index(x))
    node = root
    for item in filtered:
        if item not in node.children:
            node.children[item] = Node(item)
        node = node.children[item]
        node.count += 1

def print_tree(node, depth=0):
    if node.name != "root":
        print("  " * depth + f"{node.name}:{node.count}")
    for child in node.children.values():
        print_tree(child, depth + 1)

print_tree(root)
