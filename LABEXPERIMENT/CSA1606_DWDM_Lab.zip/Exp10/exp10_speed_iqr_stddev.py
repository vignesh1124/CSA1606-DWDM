"""
Experiment 10: Inter-quartile range and standard deviation of car speed data
Regular driving style speeds: 78.3 81.8 82 74.2 83.4 84.5 82.9 77.5 80.9 70.6
"""
import numpy as np

speed = np.array([78.3, 81.8, 82, 74.2, 83.4, 84.5, 82.9, 77.5, 80.9, 70.6])

q1 = np.percentile(speed, 25)
q3 = np.percentile(speed, 75)
iqr = q3 - q1
std = speed.std(ddof=1)

print("Speed data:", speed.tolist())
print(f"\nQ1 (25th percentile) = {q1:.4f}")
print(f"Q3 (75th percentile) = {q3:.4f}")
print(f"Inter-Quartile Range (IQR) = Q3 - Q1 = {iqr:.4f}")
print(f"\nMean = {speed.mean():.4f}")
print(f"Standard Deviation (sample) = {std:.4f}")
