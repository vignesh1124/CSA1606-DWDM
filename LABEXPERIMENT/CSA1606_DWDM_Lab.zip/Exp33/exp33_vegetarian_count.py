"""
Experiment 33: Vegetarian / non-vegetarian count
Person: Gopu, Babu, Baby, Gopal, Krishna, Jai, Dev, Malini, Hema, Anu
Vegetarian: yes, yes, yes, no, yes, no, no, yes, yes, yes
"""
from collections import Counter

people = ["Gopu","Babu","Baby","Gopal","Krishna","Jai","Dev","Malini","Hema","Anu"]
veg = ["yes","yes","yes","no","yes","no","no","yes","yes","yes"]

print("Person : Vegetarian")
for p, v in zip(people, veg):
    print(f"  {p:10s}: {v}")

counts = Counter(veg)
veg_count = counts.get("yes", 0)
nonveg_count = counts.get("no", 0)

print(f"\nVegetarian count     = {veg_count}")
print(f"Non-vegetarian count = {nonveg_count}")
print(f"\n{'Vegetarian' if veg_count > nonveg_count else 'Non-vegetarian'} count is greater "
      f"({max(veg_count, nonveg_count)} vs {min(veg_count, nonveg_count)})")

print("\nVegetarian persons:", [p for p, v in zip(people, veg) if v == "yes"])
print("Non-vegetarian persons:", [p for p, v in zip(people, veg) if v == "no"])
