"""
Experiment 34: Scatter plot of (x, y) points -- x = number of mobile
phones sold, y = money earned.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

x = [4, 1, 5, 7, 10, 2, 50, 25, 90, 36]
y = [12, 5, 13, 19, 31, 7, 153, 72, 275, 110]

print("x (phones sold):", x)
print("y (money):", y)

slope, intercept = np.polyfit(x, y, 1)
print(f"\nBest-fit line: y = {slope:.4f}x + {intercept:.4f}")
corr = np.corrcoef(x, y)[0, 1]
print(f"Correlation coefficient = {corr:.4f}")

plt.figure(figsize=(6, 5))
plt.scatter(x, y, color="teal", s=60, label="data points")
xs = np.linspace(min(x), max(x), 100)
plt.plot(xs, slope * xs + intercept, color="red", linestyle="--", label="trend line")
plt.xlabel("Number of Mobile Phones Sold")
plt.ylabel("Money")
plt.title("Scatter Plot: Mobile Phones Sold vs Money")
plt.legend()
plt.grid(alpha=0.3)
plt.savefig("exp34_scatterplot.png", dpi=110)
plt.close()
print("\nSaved plot: exp34_scatterplot.png")
