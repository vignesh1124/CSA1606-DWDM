"""
Experiment 2: Basic descriptive statistics on the 'age' attribute
-------------------------------------------------------------------
age values (sorted, increasing order):
13,15,16,16,19,20,20,21,22,22,25,25,25,25,30,33,33,35,35,35,35,36,40,45,46,52,70
"""
import numpy as np
from collections import Counter

age = [13,15,16,16,19,20,20,21,22,22,25,25,25,25,30,33,
       33,35,35,35,35,36,40,45,46,52,70]

n = len(age)
mean_val = np.mean(age)
median_val = np.median(age)

counts = Counter(age)
max_freq = max(counts.values())
modes = sorted([v for v, c in counts.items() if c == max_freq])

midrange = (min(age) + max(age)) / 2

q1 = np.percentile(age, 25)
q3 = np.percentile(age, 75)

print(f"n = {n}")
print(f"Data: {age}")
print(f"\n(a) Mean = {mean_val:.3f}")
print(f"    Median = {median_val}")
print(f"\n(b) Frequency table: {dict(sorted(counts.items()))}")
print(f"    Mode(s) = {modes} (each occurs {max_freq} times)")
if len(modes) == 1:
    modality = "unimodal"
elif len(modes) == 2:
    modality = "bimodal"
elif len(modes) == 3:
    modality = "trimodal"
else:
    modality = "multimodal"
print(f"    Modality: data is {modality} -> values {modes} are the most frequent (freq={max_freq})")
print(f"\n(c) Midrange = (min + max) / 2 = ({min(age)} + {max(age)}) / 2 = {midrange}")
print(f"\n(d) Q1 (25th percentile) = {q1}")
print(f"    Q3 (75th percentile) = {q3}")
print(f"    IQR = Q3 - Q1 = {q3 - q1}")
