"""
Experiment 40: Strike-rates scored by a batsman: 100, 70, 60, 90, 90
  (a) min-max normalization (min=0, max=1)
  (b) z-score normalization
  (c) z-score normalization using mean absolute deviation (MAD) instead
      of standard deviation
  (d) normalization by decimal scaling
"""
import numpy as np

data = np.array([100, 70, 60, 90, 90], dtype=float)
print("Data:", data.tolist())

# (a) Min-max
d_min, d_max = data.min(), data.max()
minmax = (data - d_min) / (d_max - d_min)
print(f"\n(a) Min-Max normalization (min={d_min}, max={d_max}):")
for v, nv in zip(data, minmax):
    print(f"  {v:.0f} -> {nv:.4f}")

# (b) Z-score (sample std)
mean = data.mean()
std = data.std(ddof=1)
zscore = (data - mean) / std
print(f"\n(b) Z-score normalization (mean={mean:.2f}, std={std:.4f}):")
for v, nv in zip(data, zscore):
    print(f"  {v:.0f} -> {nv:.4f}")

# (c) Z-score using mean absolute deviation
mad = np.mean(np.abs(data - mean))
zscore_mad = (data - mean) / mad
print(f"\n(c) Z-score normalization using MAD (mean={mean:.2f}, MAD={mad:.4f}):")
for v, nv in zip(data, zscore_mad):
    print(f"  {v:.0f} -> {nv:.4f}")

# (d) Decimal scaling
j = len(str(int(max(abs(x) for x in data))))
decimal_scaled = data / (10 ** j)
print(f"\n(d) Decimal scaling (j={j}, divisor=10^{j}={10**j}):")
for v, nv in zip(data, decimal_scaled):
    print(f"  {v:.0f} -> {nv:.4f}")
