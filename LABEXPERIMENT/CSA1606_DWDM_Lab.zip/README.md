# CSA1606 - Data Warehousing and Data Mining Lab

This repository contains solutions to all 42 lab exercises from the
CSA1606 Data Warehousing and Data Mining lab record.

## Structure

Each experiment has its own folder `ExpNN/` containing:
- `expNN_<description>.py` — the Python source code
- `output.txt` — the captured console output from running the script
- `*.png` — any generated charts/plots (where applicable)
- Any generated data files (`.csv`, `.arff`) used/produced by that experiment

## Important note on tooling

The original lab sheet mixes tasks meant for **R** and **WEKA**. Neither
R nor a WEKA installation is available in the environment these were
prepared in, so every experiment is implemented in **Python 3** using
standard data-science libraries — the same statistical/data-mining
concepts (descriptive statistics, normalization, binning, boxplots,
regression, Apriori/FP-Growth, Naive Bayes, Decision Trees, SVM,
K-Means clustering, etc.) are demonstrated with equivalent, runnable
code. Where an experiment referenced a dataset only available inside R
(e.g. `mtcars`, `AirPassengers`, the `water` dataset) or an external
CSV not included with the lab sheet (e.g. `diabetes.csv`), a
faithful/representative version of that dataset is embedded directly in
the script, and this is noted in the script's docstring.

## Libraries used

`numpy`, `pandas`, `matplotlib`, `scipy`, `scikit-learn`, `mlxtend`
(for Apriori / FP-Growth / association rule mining), `statsmodels`.

Install with:
```
pip install numpy pandas matplotlib scipy scikit-learn mlxtend statsmodels
```

## Running an experiment

```
cd Exp01
python3 exp01_median_grouped_data.py
```

## Experiment Index

| # | Folder | Topic |
|---|--------|-------|
| 1 | Exp01 | Approximate median from grouped frequency data |
| 2 | Exp02 | Mean, median, mode, midrange, quartiles of age data |
| 3 | Exp03 | Min-max & z-score normalization |
| 4 | Exp04 | Data smoothing (bin mean, median, boundaries) |
| 5 | Exp05 | Age/%fat stats, boxplots, scatter & Q-Q plots |
| 6 | Exp06 | Min-max, z-score, decimal scaling normalization (R-style task) |
| 7 | Exp07 | Vector stats (mean, median, mode) - pencils in boxes |
| 8 | Exp08 | Scatter plot - mobile phones sold vs money |
| 9 | Exp09 | Equal-frequency & equal-width binning + histogram |
| 10 | Exp10 | IQR and standard deviation of car speed data |
| 11 | Exp11 | Q1/Q3 quartiles of age data |
| 12 | Exp12 | Covariance and correlation - photograph preference |
| 13 | Exp13 | Equal-frequency partitioning, smoothing, histogram - prices |
| 14 | Exp14 | Class A vs B exam scores - stats & boxplot |
| 15 | Exp15 | Min-max normalization worked example + group normalization |
| 16 | Exp16 | AirPassengers histogram with custom bins |
| 17 | Exp17 | mtcars mpg & qsec multi-line chart |
| 18 | Exp18 | water dataset - mortality vs hardness linear regression |
| 19 | Exp19 | mtcars mpg by cyl boxplot |
| 20 | Exp20 | Tennis player scoring outliers boxplot |
| 21 | Exp21 | Diabetes: BloodPressure vs Age scatter & bar chart |
| 22 | Exp22 | Apriori & FP-Growth, support=3, confidence=50% |
| 23 | Exp23 | Max association rules & max frequent itemset size |
| 24 | Exp24 | Naive Bayes & Decision Tree - buys_computer dataset |
| 25 | Exp25 | Diabetes trend by age - linear & multiple regression |
| 26 | Exp26 | MONKEY dataset - Apriori & FP-Growth tree, sup=50% conf=80% |
| 27 | Exp27 | Decision Tree, Preprocessing, Logistic Regression (WEKA-style) |
| 28 | Exp28 | ARFF hotdogs dataset - frequent itemsets & rules |
| 29 | Exp29 | Rule-based vs Decision Tree classification comparison |
| 30 | Exp30 | Mall customer segmentation - K-Means clustering |
| 31 | Exp31 | Employee dataset - K-Means clustering, varying k |
| 32 | Exp32 | Naive Bayes vs SVM comparison |
| 33 | Exp33 | Vegetarian / non-vegetarian count |
| 34 | Exp34 | Scatter plot - mobile phones sold vs money (with trend line) |
| 35 | Exp35 | FP-Growth - bread/cheese/juice dataset, sup=50% conf=75% |
| 36 | Exp36 | Diabetes: Decision Tree vs SVM, accuracy & F1 |
| 37 | Exp37 | Marks binning - equal-freq, equal-width, clustering |
| 38 | Exp38 | Height/Weight decision tree - ARFF, rules, confusion matrix |
| 39 | Exp39 | TV brands ARFF - Apriori vs FP-Growth rule comparison |
| 40 | Exp40 | Strike-rate normalization (4 methods) |
| 41 | Exp41 | AvgSpeed/TotalTime - standard deviation & variance |
| 42 | Exp42 | MONKEY dataset - Apriori vs FP-Growth efficiency, metarule |
