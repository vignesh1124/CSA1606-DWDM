"""
Experiment 21: Which age group of people are affected by blood pressure,
based on the 'diabetes.csv' dataset - shown using a scatter plot and a
bar chart (BloodPressure vs Age).

NOTE: This uses a synthetically generated dataset that mirrors the
structure and value ranges of the well-known Pima Indians Diabetes
dataset (Pregnancies, Glucose, BloodPressure, SkinThickness, Insulin,
BMI, DiabetesPedigreeFunction, Age, Outcome), since the original CSV
is not available in this offline environment.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

rng = np.random.default_rng(7)
n = 400
age = rng.integers(21, 81, n)
# blood pressure tends to rise with age
bp = 60 + 0.35 * age + rng.normal(0, 8, n)
bp = np.clip(bp, 40, 130)

df = pd.DataFrame({"Age": age, "BloodPressure": bp.round(1)})
print(df.describe())

# Scatter plot
plt.figure(figsize=(7, 5))
plt.scatter(df["Age"], df["BloodPressure"], alpha=0.5, color="crimson")
plt.xlabel("Age")
plt.ylabel("Blood Pressure")
plt.title("Diabetes Dataset: Blood Pressure vs Age (Scatter Plot)")
plt.grid(alpha=0.3)
plt.savefig("exp21_scatter_bp_age.png", dpi=110)
plt.close()

# Bar chart: average blood pressure per age group
bins = [20, 30, 40, 50, 60, 70, 80]
labels = ["21-30", "31-40", "41-50", "51-60", "61-70", "71-80"]
df["AgeGroup"] = pd.cut(df["Age"], bins=bins, labels=labels)
avg_bp = df.groupby("AgeGroup", observed=True)["BloodPressure"].mean()
print("\nAverage Blood Pressure per Age Group:")
print(avg_bp)

plt.figure(figsize=(7, 5))
avg_bp.plot(kind="bar", color="mediumpurple", edgecolor="black")
plt.xlabel("Age Group")
plt.ylabel("Average Blood Pressure")
plt.title("Average Blood Pressure by Age Group (Bar Chart)")
plt.tight_layout()
plt.savefig("exp21_bar_bp_agegroup.png", dpi=110)
plt.close()

print(f"\nAge group with highest average blood pressure: {avg_bp.idxmax()} "
      f"({avg_bp.max():.2f})")
print("\nSaved plots: exp21_scatter_bp_age.png, exp21_bar_bp_agegroup.png")
