"""
Experiment 6: Normalize the value 35 for the 'age' attribute
(using min/max of the age data from the age/%fat dataset: min=23, max=61)
  (i)   min-max normalization onto range [0.0, 1.0]
  (ii)  z-score normalization (given std = 12.94 years)
  (iii) normalization by decimal scaling
"""
import numpy as np

age = [23,23,27,27,39,41,47,49,50,52,54,54,56,57,58,58,60,61]
v = 35

# (i) Min-max normalization
a_min, a_max = min(age), max(age)
minmax = (v - a_min) / (a_max - a_min) * (1.0 - 0.0) + 0.0

# (ii) Z-score normalization
mean_age = np.mean(age)
std_given = 12.94
zscore = (v - mean_age) / std_given

# (iii) Decimal scaling: divide by 10^j such that max absolute value < 1
j = len(str(int(max(abs(x) for x in age))))
decimal_scaled = v / (10 ** j)

print(f"Age data: {age}")
print(f"min = {a_min}, max = {a_max}, mean = {mean_age:.3f}")
print(f"\n(i) Min-Max normalization of v=35: ({v} - {a_min}) / ({a_max} - {a_min}) = {minmax:.4f}")
print(f"\n(ii) Z-score normalization of v=35 (std=12.94): ({v} - {mean_age:.3f}) / 12.94 = {zscore:.4f}")
print(f"\n(iii) Decimal scaling: j={j} (10^{j}={10**j}); {v} / {10**j} = {decimal_scaled:.4f}")
