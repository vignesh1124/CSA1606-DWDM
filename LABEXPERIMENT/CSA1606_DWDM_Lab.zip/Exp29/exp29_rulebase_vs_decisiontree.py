"""
Experiment 29: Prediction of Categorical Data using Rule-Based
Classification vs Decision Tree Classification (WEKA-style, reproduced
with scikit-learn: RIPPER-like rule classifier approximated using a
shallow decision tree converted to rules, compared against a full
decision tree). Compare accuracy and plot the graph.
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

rng = np.random.default_rng(3)
n = 300
age = rng.choice(["<=30", "31-40", ">40"], n)
income = rng.choice(["low", "medium", "high"], n)
student = rng.choice(["yes", "no"], n)
credit = rng.choice(["fair", "excellent"], n)

score = (
    (age == "31-40") * 2 + (income == "high") * 1 +
    (student == "yes") * 2 + (credit == "fair") * 1 +
    rng.normal(0, 1, n)
)
buys = np.where(score > np.median(score), "yes", "no")

df = pd.DataFrame({"age": age, "income": income, "student": student,
                    "credit_rating": credit, "buys_computer": buys})

encoders = {c: LabelEncoder().fit(df[c]) for c in df.columns}
enc = pd.DataFrame({c: encoders[c].transform(df[c]) for c in df.columns})
X = enc.drop(columns=["buys_computer"])
y = enc["buys_computer"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=0)

# Full decision tree
dt_full = DecisionTreeClassifier(criterion="entropy", random_state=0)
dt_full.fit(X_train, y_train)
acc_tree = accuracy_score(y_test, dt_full.predict(X_test))

# "Rule-based" classifier: shallow decision tree (depth=2) -> read off as IF-THEN rules
dt_rules = DecisionTreeClassifier(criterion="entropy", max_depth=2, random_state=0)
dt_rules.fit(X_train, y_train)
acc_rules = accuracy_score(y_test, dt_rules.predict(X_test))

print("Rule-based classifier (shallow tree, depth=2) rules:")
print(export_text(dt_rules, feature_names=list(X.columns)))
print(f"Rule-based classifier accuracy: {acc_rules:.4f}")

print("\nFull Decision Tree:")
print(export_text(dt_full, feature_names=list(X.columns)))
print(f"Decision Tree accuracy: {acc_tree:.4f}")

plt.figure(figsize=(6, 5))
plt.bar(["Rule-Based", "Decision Tree"], [acc_rules, acc_tree], color=["goldenrod", "steelblue"])
plt.ylabel("Accuracy")
plt.ylim(0, 1)
plt.title("Rule-Based vs Decision Tree Classification Accuracy")
for i, v in enumerate([acc_rules, acc_tree]):
    plt.text(i, v + 0.02, f"{v:.3f}", ha="center")
plt.savefig("exp29_accuracy_comparison.png", dpi=110)
plt.close()
print("\nSaved plot: exp29_accuracy_comparison.png")
