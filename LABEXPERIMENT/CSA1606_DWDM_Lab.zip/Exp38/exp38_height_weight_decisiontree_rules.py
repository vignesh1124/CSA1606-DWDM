"""
Experiment 38: Decision tree given:
   Height > 180cm? --Yes--> Male
                   --No--> Weight > 80kg? --Yes--> Male
                                            --No--> Female
  a) Create the dataset (ARFF format) for this tree, calculate accuracy
  b) Generate rules using rule-based induction from the tree
  c) Compare both algorithms and plot the confusion matrix
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.metrics import accuracy_score, confusion_matrix, ConfusionMatrixDisplay

rng = np.random.default_rng(1)
n = 60
height = rng.normal(170, 12, n).clip(150, 200)
weight = rng.normal(70, 15, n).clip(45, 110)

def label_from_tree(h, w):
    if h > 180:
        return "Male"
    else:
        return "Male" if w > 80 else "Female"

gender = [label_from_tree(h, w) for h, w in zip(height, weight)]
df = pd.DataFrame({"Height": height.round(1), "Weight": weight.round(1), "Gender": gender})

arff_lines = [
    "@RELATION gender_prediction", "",
    "@ATTRIBUTE Height NUMERIC",
    "@ATTRIBUTE Weight NUMERIC",
    "@ATTRIBUTE Gender {Male,Female}", "",
    "@DATA",
]
for _, r in df.iterrows():
    arff_lines.append(f"{r.Height},{r.Weight},{r.Gender}")
with open("gender.arff", "w") as f:
    f.write("\n".join(arff_lines))
print("=== ARFF file (first 10 data lines shown) ===")
print("\n".join(arff_lines[:9 + 10]))

X = df[["Height", "Weight"]]
y = df["Gender"]

# a) Decision tree trained to (re)discover the given rule
dt = DecisionTreeClassifier(criterion="entropy", random_state=0)
dt.fit(X, y)
dt_pred = dt.predict(X)
dt_acc = accuracy_score(y, dt_pred)
print(f"\n(a) Decision Tree accuracy on this data: {dt_acc:.4f}")
print(export_text(dt, feature_names=list(X.columns)))

# b) Rule-based induction: directly encode the original tree as IF-THEN rules
print("\n(b) Rule-based induction (rules read directly from the given tree):")
print("  RULE 1: IF Height > 180 THEN Gender = Male")
print("  RULE 2: IF Height <= 180 AND Weight > 80 THEN Gender = Male")
print("  RULE 3: IF Height <= 180 AND Weight <= 80 THEN Gender = Female")

def rule_based_predict(h, w):
    if h > 180:
        return "Male"
    return "Male" if w > 80 else "Female"

rb_pred = [rule_based_predict(h, w) for h, w in zip(df.Height, df.Weight)]
rb_acc = accuracy_score(y, rb_pred)
print(f"  Rule-based classifier accuracy: {rb_acc:.4f}")

print(f"\n(c) Comparison: Decision Tree accuracy={dt_acc:.4f} vs Rule-Based accuracy={rb_acc:.4f}")

cm = confusion_matrix(y, dt_pred, labels=["Male", "Female"])
print(f"Confusion Matrix (Decision Tree):\n{cm}")

disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=["Male", "Female"])
disp.plot(cmap="Blues")
plt.title("Confusion Matrix: Decision Tree (Gender Prediction)")
plt.savefig("exp38_confusion_matrix.png", dpi=110)
plt.close()
print("\nSaved: gender.arff, exp38_confusion_matrix.png")
