"""
Experiment 14: Compare two Year-9 classes' exam results
Class A: 76,35,47,64,95,66,89,36,84
Class B: 51,56,84,60,59,70,63,66,50
  (i)  mean, median, range for each class
  (ii) boxplot and inferences
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

classA = [76, 35, 47, 64, 95, 66, 89, 36, 84]
classB = [51, 56, 84, 60, 59, 70, 63, 66, 50]

for name, data in [("Class A", classA), ("Class B", classB)]:
    data = np.array(data)
    mean_v = data.mean()
    median_v = np.median(data)
    range_v = data.max() - data.min()
    print(f"{name}: {data.tolist()}")
    print(f"  Mean   = {mean_v:.3f}")
    print(f"  Median = {median_v}")
    print(f"  Range  = {range_v} (max={data.max()}, min={data.min()})\n")

mA, mB = np.mean(classA), np.mean(classB)
medA, medB = np.median(classA), np.median(classB)
rA, rB = max(classA) - min(classA), max(classB) - min(classB)

print("(i) Comparison:")
print(f"  Higher mean:   {'Class A' if mA > mB else 'Class B'} ({max(mA, mB):.2f})")
print(f"  Higher median: {'Class A' if medA > medB else 'Class B'} ({max(medA, medB)})")
print(f"  Higher range:  {'Class A' if rA > rB else 'Class B'} ({max(rA, rB)})")

plt.figure(figsize=(6, 5))
plt.boxplot([classA, classB], tick_labels=["Class A", "Class B"])
plt.ylabel("Scores")
plt.title("Boxplot: Class A vs Class B Exam Scores")
plt.savefig("exp14_boxplot.png", dpi=110)
plt.close()

print("""
(ii) Inference from boxplot:
Class A shows a wider spread (larger IQR and range) with scores ranging
from very low (35-36) to very high (95), indicating more inconsistent
performance. Class B's scores are more tightly clustered around the
median, indicating more consistent performance across students, even
though Class A's mean/median may be pulled around by its wider spread.
""")
print("Saved plot: exp14_boxplot.png")
