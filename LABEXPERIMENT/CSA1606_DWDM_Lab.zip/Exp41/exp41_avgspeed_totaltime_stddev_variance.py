"""
Experiment 41: AvgSpeed and TotalTime for 9 randomly selected cars
  a) Calculate the standard deviation of AvgSpeed and TotalTime
  b) Calculate the variance of AvgSpeed and TotalTime
"""
import numpy as np

avg_speed = np.array([78, 81, 82, 74, 83, 82, 77, 80, 70], dtype=float)
total_time = np.array([39, 37, 36, 42, 35, 36, 40, 38, 46], dtype=float)

print("AvgSpeed (kph):", avg_speed.tolist())
print("TotalTime (mins):", total_time.tolist())

print(f"\n(a) Standard deviation:")
print(f"    AvgSpeed  std (sample) = {avg_speed.std(ddof=1):.4f}")
print(f"    TotalTime std (sample) = {total_time.std(ddof=1):.4f}")

print(f"\n(b) Variance:")
print(f"    AvgSpeed  variance (sample) = {avg_speed.var(ddof=1):.4f}")
print(f"    TotalTime variance (sample) = {total_time.var(ddof=1):.4f}")

corr = np.corrcoef(avg_speed, total_time)[0, 1]
print(f"\nCorrelation(AvgSpeed, TotalTime) = {corr:.4f}")
print("(Negative correlation expected: higher average speed -> shorter total time)")
