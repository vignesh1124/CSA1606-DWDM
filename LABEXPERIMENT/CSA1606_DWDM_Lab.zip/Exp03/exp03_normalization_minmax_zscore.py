"""
Experiment 3: Data Preprocessing - Reduction and Transformation
Normalize {200, 300, 400, 600, 1000} using:
  (a) min-max normalization (new_min=0, new_max=1)
  (b) z-score normalization
"""
import numpy as np

data = np.array([200, 300, 400, 600, 1000], dtype=float)

# (a) Min-Max normalization
d_min, d_max = data.min(), data.max()
new_min, new_max = 0, 1
minmax_norm = (data - d_min) / (d_max - d_min) * (new_max - new_min) + new_min

# (b) Z-score normalization
mean = data.mean()
std = data.std(ddof=1)  # sample standard deviation
zscore_norm = (data - mean) / std

print("Original data:", data.tolist())
print(f"\n(a) Min-Max Normalization (min={new_min}, max={new_max})")
print(f"    min = {d_min}, max = {d_max}")
for v, nv in zip(data, minmax_norm):
    print(f"    {v:.0f} -> {nv:.4f}")

print(f"\n(b) Z-score Normalization")
print(f"    mean = {mean:.2f}, std (sample) = {std:.4f}")
for v, nv in zip(data, zscore_norm):
    print(f"    {v:.0f} -> {nv:.4f}")
