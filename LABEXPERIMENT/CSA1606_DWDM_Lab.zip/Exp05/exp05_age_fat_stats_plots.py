"""
Experiment 5: Age & Body Fat data for 18 adults
  (a) mean, median, standard deviation of age and %fat
  (b) boxplots for age and %fat
  (c) scatter plot and Q-Q plot of the two variables
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from scipy import stats

age = [23,23,27,27,39,41,47,49,50,52,54,54,56,57,58,58,60,61]
fat = [9.5,26.5,7.8,17.8,31.4,25.9,27.4,27.2,31.2,34.6,42.5,28.8,33.4,30.2,34.1,32.9,41.2,35.7]

age = np.array(age, dtype=float)
fat = np.array(fat, dtype=float)

print("Age:", age.tolist())
print("%Fat:", fat.tolist())

print(f"\n(a) Age  -> mean={age.mean():.3f}, median={np.median(age):.3f}, std={age.std(ddof=1):.3f}")
print(f"    %Fat -> mean={fat.mean():.3f}, median={np.median(fat):.3f}, std={fat.std(ddof=1):.3f}")

# (b) Boxplots
fig, axes = plt.subplots(1, 2, figsize=(8, 5))
axes[0].boxplot(age, tick_labels=["Age"])
axes[0].set_title("Boxplot of Age")
axes[1].boxplot(fat, tick_labels=["%Fat"])
axes[1].set_title("Boxplot of %Fat")
plt.tight_layout()
plt.savefig("exp05_boxplots.png", dpi=110)
plt.close()

# (c) Scatter plot
plt.figure(figsize=(6, 5))
plt.scatter(age, fat, color="steelblue")
plt.xlabel("Age")
plt.ylabel("%Fat")
plt.title("Scatter Plot: Age vs %Fat")
plt.grid(alpha=0.3)
plt.savefig("exp05_scatter.png", dpi=110)
plt.close()

# Q-Q plot (age vs fat quantiles, and each vs normal distribution)
fig, axes = plt.subplots(1, 2, figsize=(10, 5))
stats.probplot(age, dist="norm", plot=axes[0])
axes[0].set_title("Q-Q Plot: Age vs Normal")
stats.probplot(fat, dist="norm", plot=axes[1])
axes[1].set_title("Q-Q Plot: %Fat vs Normal")
plt.tight_layout()
plt.savefig("exp05_qqplot.png", dpi=110)
plt.close()

print("\nSaved plots: exp05_boxplots.png, exp05_scatter.png, exp05_qqplot.png")
