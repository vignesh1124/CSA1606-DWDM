"""
Experiment 17: Multiple lines in a line chart using attributes 'mpg' and
'qsec' of the 'mtcars' dataset (both plotted against car index on one plot).
(mtcars is R's built-in Motor Trend Car Road Tests dataset, reproduced
here since R/CRAN datasets are not downloadable in this offline
environment.)
"""
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

cars = ["Mazda RX4","Mazda RX4 Wag","Datsun 710","Hornet 4 Drive","Hornet Sportabout",
        "Valiant","Duster 360","Merc 240D","Merc 230","Merc 280","Merc 280C","Merc 450SE",
        "Merc 450SL","Merc 450SLC","Cadillac Fleetwood","Lincoln Continental",
        "Chrysler Imperial","Fiat 128","Honda Civic","Toyota Corolla","Toyota Corona",
        "Dodge Challenger","AMC Javelin","Camaro Z28","Pontiac Firebird","Fiat X1-9",
        "Porsche 914-2","Lotus Europa","Ford Pantera L","Ferrari Dino","Maserati Bora","Volvo 142E"]

mpg = [21.0,21.0,22.8,21.4,18.7,18.1,14.3,24.4,22.8,19.2,17.8,16.4,17.3,15.2,10.4,10.4,14.7,
       32.4,30.4,33.9,21.5,15.5,15.2,13.3,19.2,27.3,26.0,30.4,15.8,19.7,15.0,21.4]

qsec = [16.46,17.02,18.61,19.44,17.02,20.22,15.84,20.00,22.90,18.30,18.90,17.40,17.60,18.00,
        17.98,17.82,17.42,19.47,18.52,19.90,20.01,16.87,17.30,15.41,17.05,18.90,16.70,16.90,
        14.50,15.50,14.60,18.60]

print("mtcars mpg:", mpg)
print("mtcars qsec:", qsec)

x = list(range(1, len(cars) + 1))
plt.figure(figsize=(10, 6))
plt.plot(x, mpg, color="blue", marker="o", label="mpg")
plt.plot(x, qsec, color="red", marker="s", label="qsec")
plt.xlabel("Car index")
plt.ylabel("Value")
plt.title("mtcars: mpg and qsec (multiple lines, single plot)")
plt.legend()
plt.grid(alpha=0.3)
plt.savefig("exp17_mtcars_multiline.png", dpi=110)
plt.close()
print("\nSaved plot: exp17_mtcars_multiline.png")
