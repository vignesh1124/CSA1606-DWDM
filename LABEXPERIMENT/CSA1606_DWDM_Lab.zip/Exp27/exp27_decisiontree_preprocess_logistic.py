"""
Experiment 27: Prediction of Categorical Data using Decision Tree
Algorithm (WEKA-style workflow, reproduced here with Python/scikit-learn
since WEKA is a GUI desktop tool not available in this environment):
  a) Tree (Decision Tree classifier)
  b) Preprocess (handle categorical encoding, check missing values)
  c) Logistic (Logistic Regression classifier for comparison)

Dataset: buys_computer (same as Experiment 24).
"""
import pandas as pd
from sklearn.preprocessing import LabelEncoder
from sklearn.tree import DecisionTreeClassifier, export_text
from sklearn.linear_model import LogisticRegression
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score

data = {
    "age":     ["<=30","<=30","31...40",">40",">40",">40","31...40","<=30","<=30",">40","<=30","31...40","31...40",">40"],
    "income":  ["high","high","high","medium","low","low","low","medium","low","medium","medium","medium","high","medium"],
    "student": ["no","no","no","no","yes","yes","yes","no","yes","yes","yes","no","yes","no"],
    "credit_rating": ["fair","excellent","fair","fair","fair","excellent","excellent","fair","fair","fair","excellent","excellent","fair","excellent"],
    "buys_computer": ["no","no","yes","yes","yes","no","yes","no","yes","yes","yes","yes","yes","no"],
}
df = pd.DataFrame(data)

print("=== (b) Preprocess ===")
print("Raw data:")
print(df)
print(f"\nMissing values per column:\n{df.isnull().sum()}")

encoders = {col: LabelEncoder().fit(df[col]) for col in df.columns}
enc_df = pd.DataFrame({col: encoders[col].transform(df[col]) for col in df.columns})
print("\nLabel-encoded data (categorical -> numeric, required before modeling):")
print(enc_df)

X = enc_df.drop(columns=["buys_computer"])
y = enc_df["buys_computer"]

print("\n=== (a) Tree (Decision Tree) ===")
dt = DecisionTreeClassifier(criterion="entropy", random_state=0)
dt.fit(X, y)
print(export_text(dt, feature_names=list(X.columns)))
dt_acc = accuracy_score(y, dt.predict(X))
print(f"Decision Tree training accuracy: {dt_acc:.3f}")

print("\n=== (c) Logistic (Logistic Regression) ===")
logreg = LogisticRegression(max_iter=1000)
logreg.fit(X, y)
logreg_acc = accuracy_score(y, logreg.predict(X))
print(f"Coefficients: {dict(zip(X.columns, logreg.coef_[0].round(4)))}")
print(f"Intercept: {logreg.intercept_[0]:.4f}")
print(f"Logistic Regression training accuracy: {logreg_acc:.3f}")

print(f"\nSummary: Decision Tree accuracy={dt_acc:.3f} vs Logistic Regression accuracy={logreg_acc:.3f}")
