"""
Experiment 37: Marks scored partitioned into 3 bins using:
  (a) equal-frequency (equi-depth) partitioning
  (b) equal-width partitioning
  (c) clustering (K-Means, k=3)
Plot the data points using a histogram.
Data: 55,60,71,63,55,65,50,55,58,59,61,63,65,67,71,72,75
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans

marks = [55,60,71,63,55,65,50,55,58,59,61,63,65,67,71,72,75]
sorted_marks = sorted(marks)
print("Sorted data:", sorted_marks)

n_bins = 3
bin_size = len(sorted_marks) // n_bins
remainder = len(sorted_marks) % n_bins
freq_bins, idx = [], 0
for i in range(n_bins):
    size = bin_size + (1 if i < remainder else 0)
    freq_bins.append(sorted_marks[idx:idx + size])
    idx += size

print("\n(a) Equal-frequency partitioning:")
for i, b in enumerate(freq_bins, 1):
    print(f"  Bin {i}: {b}")

mn, mx = min(sorted_marks), max(sorted_marks)
width = (mx - mn) / n_bins
width_bins = [[] for _ in range(n_bins)]
for v in sorted_marks:
    b_idx = min(int((v - mn) / width), n_bins - 1)
    width_bins[b_idx].append(v)

print(f"\n(b) Equal-width partitioning (width={width:.2f}):")
for i, b in enumerate(width_bins, 1):
    print(f"  Bin {i}: {b}")

X = np.array(marks).reshape(-1, 1)
km = KMeans(n_clusters=3, random_state=42, n_init=10).fit(X)
labels = km.labels_
cluster_bins = {c: [] for c in range(3)}
for v, c in zip(marks, labels):
    cluster_bins[c].append(v)
# order clusters by their mean value for readability
ordered = sorted(cluster_bins.items(), key=lambda kv: np.mean(kv[1]))

print("\n(c) Clustering (K-Means, k=3):")
for i, (c, vals) in enumerate(ordered, 1):
    print(f"  Cluster {i} (center~{np.mean(vals):.2f}): {sorted(vals)}")

plt.figure(figsize=(7, 5))
plt.hist(marks, bins=n_bins, color="plum", edgecolor="black")
plt.xlabel("Marks")
plt.ylabel("Frequency")
plt.title("Histogram of Marks (3 bins)")
plt.savefig("exp37_histogram.png", dpi=110)
plt.close()
print("\nSaved plot: exp37_histogram.png")
