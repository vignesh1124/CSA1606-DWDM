"""
Experiment 15:
  Part 1: Worked min-max normalization example.
     min(F) = $50,000, max(F) = $100,000, new range [0,1], v = $80,000
  Part 2: Normalize {200, 300, 400, 600, 1000} using
     (a) min-max normalization (min=0, max=1)
     (b) z-score normalization
"""
import numpy as np

print("Part 1: Worked min-max normalization example")
f_min, f_max = 50000, 100000
v = 80000
new_min, new_max = 0, 1
v_norm = (v - f_min) / (f_max - f_min) * (new_max - new_min) + new_min
print(f"  min = {f_min}, max = {f_max}, v = {v}")
print(f"  v' = (v - min)/(max - min) * (new_max - new_min) + new_min")
print(f"  v' = ({v} - {f_min})/({f_max} - {f_min}) = {v_norm}")

print("\nPart 2: Normalize {200, 300, 400, 600, 1000}")
data = np.array([200, 300, 400, 600, 1000], dtype=float)

d_min, d_max = data.min(), data.max()
minmax_norm = (data - d_min) / (d_max - d_min)
print("\n(a) Min-Max normalization (min=0, max=1):")
for v_, nv in zip(data, minmax_norm):
    print(f"  {v_:.0f} -> {nv:.4f}")

mean = data.mean()
std = data.std(ddof=1)
zscore_norm = (data - mean) / std
print(f"\n(b) Z-score normalization (mean={mean:.2f}, std={std:.4f}):")
for v_, nv in zip(data, zscore_norm):
    print(f"  {v_:.0f} -> {nv:.4f}")
