"""
Experiment 7: Vector of pencils in boxes - mean, median, mode
Box1..Box10 = 9, 25, 23, 12, 11, 6, 7, 8, 9, 10
"""
import numpy as np
from collections import Counter

boxes = [f"Box{i}" for i in range(1, 11)]
pencils = [9, 25, 23, 12, 11, 6, 7, 8, 9, 10]

vec = np.array(pencils)

counts = Counter(pencils)
max_freq = max(counts.values())
modes = sorted([v for v, c in counts.items() if c == max_freq])

print("Vector (pencils per box):")
for b, p in zip(boxes, pencils):
    print(f"  {b}: {p}")

print(f"\nMean   = {vec.mean():.3f}")
print(f"Median = {np.median(vec)}")
if max_freq > 1:
    print(f"Mode   = {modes} (occurs {max_freq} times)")
else:
    print("Mode   = No mode (all values occur exactly once)")
