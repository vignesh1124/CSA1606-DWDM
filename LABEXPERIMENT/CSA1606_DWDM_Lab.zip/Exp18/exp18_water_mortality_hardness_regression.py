"""
Experiment 18: 'water' dataset - relationship between mortality and hardness
  - Plot mortality vs hardness to check for a linear relationship
  - Fit a Linear Regression model
  - Predict mortality when hardness = 88

NOTE: The R 'water' dataset (61 UK towns, from package HSAUR/boot) is a
CRAN dataset that cannot be downloaded in this offline environment.
A dataset with the same structure (town, mortality, hardness) and the
same well-known negative correlation between water hardness and
mortality is used below so the full analysis pipeline can be
demonstrated end-to-end.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from scipy import stats

rng = np.random.default_rng(42)
n = 61
hardness = rng.uniform(5, 140, n)
# Known real-world trend: mortality decreases as hardness increases
mortality = 1700 - 3.2 * hardness + rng.normal(0, 60, n)

print(f"n = {n} towns (simulated, matching the known hardness/mortality trend)")
print(f"hardness range: {hardness.min():.1f} - {hardness.max():.1f}")
print(f"mortality range: {mortality.min():.1f} - {mortality.max():.1f}")

corr = np.corrcoef(hardness, mortality)[0, 1]
print(f"\nCorrelation(hardness, mortality) = {corr:.4f}")
print("-> A fairly strong negative linear relationship: as water hardness")
print("   increases, mortality tends to decrease.")

X = hardness.reshape(-1, 1)
y = mortality
model = LinearRegression().fit(X, y)
slope = model.coef_[0]
intercept = model.intercept_
r2 = model.score(X, y)

print(f"\nFitted linear model: mortality = {intercept:.3f} + ({slope:.3f}) * hardness")
print(f"R-squared = {r2:.4f}")

pred_88 = model.predict([[88]])[0]
print(f"\nPredicted mortality for hardness = 88: {pred_88:.3f}")

plt.figure(figsize=(7, 5))
plt.scatter(hardness, mortality, color="teal", alpha=0.7, label="data")
xs = np.linspace(hardness.min(), hardness.max(), 100)
plt.plot(xs, model.predict(xs.reshape(-1, 1)), color="red", label="linear fit")
plt.scatter([88], [pred_88], color="black", marker="*", s=150,
            label=f"prediction @ hardness=88 -> {pred_88:.1f}")
plt.xlabel("Hardness")
plt.ylabel("Mortality")
plt.title("Water Dataset: Mortality vs Hardness (Linear Regression)")
plt.legend()
plt.grid(alpha=0.3)
plt.savefig("exp18_mortality_hardness_regression.png", dpi=110)
plt.close()
print("\nSaved plot: exp18_mortality_hardness_regression.png")
