"""
Experiment 20: Tennis coach wants to detect scoring outliers among players.
Visualize the distribution of points scored using a boxplot.
"""
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

players = {
    "Player A": [22, 25, 24, 23, 26, 21, 25, 60],   # 60 is a potential outlier
    "Player B": [15, 18, 17, 16, 19, 15, 18, 17],
    "Player C": [30, 32, 31, 5, 29, 33, 30, 31],    # 5 is a potential outlier
}

for name, scores in players.items():
    arr = np.array(scores)
    q1, q3 = np.percentile(arr, [25, 75])
    iqr = q3 - q1
    lower, upper = q1 - 1.5 * iqr, q3 + 1.5 * iqr
    outliers = arr[(arr < lower) | (arr > upper)]
    print(f"{name}: scores={scores}")
    print(f"  Q1={q1}, Q3={q3}, IQR={iqr}, outlier bounds=[{lower:.1f}, {upper:.1f}]")
    print(f"  Outliers detected: {outliers.tolist() if len(outliers) else 'None'}\n")

plt.figure(figsize=(7, 5))
plt.boxplot(players.values(), tick_labels=players.keys())
plt.ylabel("Points scored")
plt.title("Boxplot: Points Scored per Player (Outlier Detection)")
plt.savefig("exp20_tennis_boxplot.png", dpi=110)
plt.close()
print("Saved plot: exp20_tennis_boxplot.png")
