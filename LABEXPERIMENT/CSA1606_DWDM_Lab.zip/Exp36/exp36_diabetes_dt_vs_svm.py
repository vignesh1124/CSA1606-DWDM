"""
Experiment 36: Prediction of Diabetes Data using Decision Tree classifier
vs Support Vector Machine (SVM) classifier. Show accuracy and F1-measure,
plot the graph, and summarize.
(WEKA-style task reproduced with scikit-learn; synthetic Pima-style
dataset used, same structure as Experiments 21/25.)
"""
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.tree import DecisionTreeClassifier
from sklearn.svm import SVC
from sklearn.metrics import accuracy_score, f1_score, confusion_matrix

rng = np.random.default_rng(21)
n = 600
age = rng.integers(21, 81, n)
bmi = rng.normal(30, 6, n).clip(15, 55)
glucose = rng.normal(120, 30, n).clip(50, 250)
bp = rng.normal(70, 12, n).clip(40, 130)

logit = -9 + 0.03 * age + 0.10 * bmi + 0.035 * glucose + 0.01 * bp
prob = 1 / (1 + np.exp(-logit))
outcome = (rng.random(n) < prob).astype(int)

df = pd.DataFrame({"Age": age, "BMI": bmi, "Glucose": glucose,
                    "BloodPressure": bp, "Outcome": outcome})
print(df.describe())
print(f"\nClass balance:\n{df.Outcome.value_counts()}")

X = df.drop(columns=["Outcome"])
y = df["Outcome"]
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.25,
                                                      random_state=0, stratify=y)
scaler = StandardScaler().fit(X_train)
X_train_s, X_test_s = scaler.transform(X_train), scaler.transform(X_test)

dt = DecisionTreeClassifier(max_depth=5, random_state=0).fit(X_train, y_train)
svm = SVC(kernel="rbf").fit(X_train_s, y_train)

dt_pred = dt.predict(X_test)
svm_pred = svm.predict(X_test_s)

dt_acc, dt_f1 = accuracy_score(y_test, dt_pred), f1_score(y_test, dt_pred)
svm_acc, svm_f1 = accuracy_score(y_test, svm_pred), f1_score(y_test, svm_pred)

print(f"\nDecision Tree -> Accuracy: {dt_acc:.4f}, F1-score: {dt_f1:.4f}")
print(f"Confusion Matrix (DT):\n{confusion_matrix(y_test, dt_pred)}")

print(f"\nSVM           -> Accuracy: {svm_acc:.4f}, F1-score: {svm_f1:.4f}")
print(f"Confusion Matrix (SVM):\n{confusion_matrix(y_test, svm_pred)}")

plt.figure(figsize=(6, 5))
labels = ["Decision Tree", "SVM"]
accs, f1s = [dt_acc, svm_acc], [dt_f1, svm_f1]
x = np.arange(2)
w = 0.35
plt.bar(x - w/2, accs, w, label="Accuracy", color="royalblue")
plt.bar(x + w/2, f1s, w, label="F1-score", color="darkorange")
plt.xticks(x, labels)
plt.ylim(0, 1)
plt.legend()
plt.title("Diabetes Prediction: Decision Tree vs SVM")
plt.savefig("exp36_dt_vs_svm_diabetes.png", dpi=110)
plt.close()

better = "Decision Tree" if dt_acc > svm_acc else "SVM"
print(f"\nSummary: {better} achieved higher accuracy on this synthetic diabetes dataset.")
print("Saved plot: exp36_dt_vs_svm_diabetes.png")
