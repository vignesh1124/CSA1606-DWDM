"""
Experiment 39: Create an ARFF file for the table below and compare
Apriori and FP-Growth generated rules. Identify unique rules generated
by each algorithm.
  Min_sup = 2, min_confidence = 50%

T1: SONY, BPL, LG
T2: BPL, SAMSUNG
T3: BPL, ONIDA
T4: SONY, BPL, SAMSUNG
T5: SONY, ONIDA
T6: BPL, ONIDA
T7: SONY, ONIDA
T8: SONY, BPL, ONIDA, LG
T9: SONY, BPL, ONIDA
"""
import pandas as pd
from mlxtend.preprocessing import TransactionEncoder
from mlxtend.frequent_patterns import apriori, fpgrowth, association_rules

transactions = [
    ["SONY", "BPL", "LG"],
    ["BPL", "SAMSUNG"],
    ["BPL", "ONIDA"],
    ["SONY", "BPL", "SAMSUNG"],
    ["SONY", "ONIDA"],
    ["BPL", "ONIDA"],
    ["SONY", "ONIDA"],
    ["SONY", "BPL", "ONIDA", "LG"],
    ["SONY", "BPL", "ONIDA"],
]
n = len(transactions)
for i, t in enumerate(transactions, 1):
    print(f"T{i}: {t}")

arff_lines = ["@RELATION television_brands", "",
              "@ATTRIBUTE SONY {t,f}", "@ATTRIBUTE BPL {t,f}",
              "@ATTRIBUTE LG {t,f}", "@ATTRIBUTE SAMSUNG {t,f}",
              "@ATTRIBUTE ONIDA {t,f}", "", "@DATA"]
items_order = ["SONY", "BPL", "LG", "SAMSUNG", "ONIDA"]
for t in transactions:
    arff_lines.append(",".join(["t" if it in t else "f" for it in items_order]))
with open("tv_brands.arff", "w") as f:
    f.write("\n".join(arff_lines))
print("\n=== ARFF file content ===")
print("\n".join(arff_lines))

te = TransactionEncoder()
te_ary = te.fit(transactions).transform(transactions)
df = pd.DataFrame(te_ary, columns=te.columns_)

min_support = 2 / n
min_conf = 0.50
print(f"\nmin_sup=2 -> support fraction={min_support:.4f}, min_conf={min_conf}")

freq_a = apriori(df, min_support=min_support, use_colnames=True)
rules_a = association_rules(freq_a, metric="confidence", min_threshold=min_conf, num_itemsets=len(freq_a))
print("\n--- Apriori Rules ---")
print(rules_a[["antecedents", "consequents", "support", "confidence"]].to_string(index=False))

freq_f = fpgrowth(df, min_support=min_support, use_colnames=True)
rules_f = association_rules(freq_f, metric="confidence", min_threshold=min_conf, num_itemsets=len(freq_f))
print("\n--- FP-Growth Rules ---")
print(rules_f[["antecedents", "consequents", "support", "confidence"]].to_string(index=False))

def rule_set(rules_df):
    return set((frozenset(a), frozenset(c)) for a, c in zip(rules_df.antecedents, rules_df.consequents))

set_a, set_f = rule_set(rules_a), rule_set(rules_f)
print(f"\nApriori produced {len(set_a)} rules; FP-Growth produced {len(set_f)} rules.")
print(f"Rules only in Apriori:   {set_a - set_f if set_a - set_f else 'None'}")
print(f"Rules only in FP-Growth: {set_f - set_a if set_f - set_a else 'None'}")
print("Both algorithms explore the same search space of frequent itemsets, so for")
print("identical support/confidence thresholds they always yield the identical rule set.")
